package com.turbodownloadmanager.service

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

object DownloadController {
    const val EXTRA_ID = "download_id"
    fun start(context: Context, id: Long) {
        val i = Intent(context, DownloadForegroundService::class.java).setAction(DownloadForegroundService.ACTION_START).putExtra(EXTRA_ID, id)
        ContextCompat.startForegroundService(context, i)
    }
    fun pause(context: Context, id: Long) = send(context, DownloadForegroundService.ACTION_PAUSE, id)
    fun resume(context: Context, id: Long) = send(context, DownloadForegroundService.ACTION_RESUME, id)
    fun cancel(context: Context, id: Long) = send(context, DownloadForegroundService.ACTION_CANCEL, id)
    private fun send(context: Context, action: String, id: Long) { context.startService(Intent(context, DownloadForegroundService::class.java).setAction(action).putExtra(EXTRA_ID, id)) }
}
