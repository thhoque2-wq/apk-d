package com.turbodownloadmanager.utils

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.turbodownloadmanager.service.DownloadController
import com.turbodownloadmanager.service.DownloadForegroundService

class NotificationHelper(private val context: Context) {
    companion object { const val CHANNEL = "downloads"; const val ID = 4201 }
    init { if (Build.VERSION.SDK_INT >= 26) context.getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL, "Downloads", NotificationManager.IMPORTANCE_LOW)) }
    fun notification(id: Long, filename: String, progress: Int, speed: String, action: String): Notification {
        val control = Intent(context, DownloadForegroundService::class.java).setAction(action).putExtra(DownloadController.EXTRA_ID, id)
        val pending = PendingIntent.getService(context, (id + action.hashCode()).toInt(), control, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cancel = Intent(context, DownloadForegroundService::class.java).setAction(DownloadForegroundService.ACTION_CANCEL).putExtra(DownloadController.EXTRA_ID, id)
        val cancelPending = PendingIntent.getService(context, (id + 9001).toInt(), cancel, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val title = if (filename.length > 40) filename.take(37) + "..." else filename
        return NotificationCompat.Builder(context, CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle(title)
            .setContentText(if (progress >= 0) "$progress% • $speed" else speed).setProgress(100, progress.coerceIn(0, 100), progress < 0).setOngoing(true)
            .addAction(if (action == DownloadForegroundService.ACTION_PAUSE) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, if (action == DownloadForegroundService.ACTION_PAUSE) "Pause" else "Resume", pending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancelPending).build()
    }
    fun completion(filename: String, id: Long): Notification = NotificationCompat.Builder(context, CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle("Download complete").setContentText(filename).setAutoCancel(true).build()
    fun error(filename: String, message: String): Notification = NotificationCompat.Builder(context, CHANNEL).setSmallIcon(android.R.drawable.stat_notify_error).setContentTitle("Download failed").setContentText("$filename: $message").setAutoCancel(true).build()
}
