package com.turbodownloadmanager.viewmodel

import android.app.Application
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.turbodownloadmanager.data.AppSettings
import com.turbodownloadmanager.data.SettingsStore
import com.turbodownloadmanager.db.*
import com.turbodownloadmanager.repository.DownloadRepository
import com.turbodownloadmanager.service.DownloadController
import com.turbodownloadmanager.utils.UrlUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = DownloadRepository(AppDatabase.get(app).downloadDao())
    private val settingsStore = SettingsStore(app)
    val downloads = repo.all.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _settings = MutableStateFlow(settingsStore.load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()
    private val _prefill = MutableStateFlow("")
    val prefill: StateFlow<String> = _prefill.asStateFlow()
    private val _message = MutableSharedFlow<String>()
    val message = _message.asSharedFlow()

    fun setPrefill(text: String) { _prefill.value = UrlUtils.extractUrl(text) ?: text.trim() }

    fun addUrl(raw: String, autoStart: Boolean = true) {
        val url = UrlUtils.normalize(raw) ?: run { viewModelScope.launch { _message.emit("Please enter a valid HTTP or HTTPS URL.") }; return }
        viewModelScope.launch {
            val name = url.substringAfterLast('/').substringBefore('?').ifBlank { "download" }.take(120)
            val id = repo.insert(DownloadEntity(url = url, fileName = name, connectionCount = settings.value.parallelConnections))
            val item = repo.get(id) ?: return@launch
            repo.update(item.copy(tempPath = java.io.File(getApplication<Application>().cacheDir, "downloads/$id.part").path))
            if (autoStart && settings.value.autoStart) DownloadController.start(getApplication(), id)
            _prefill.value = ""
        }
    }

    fun pause(item: DownloadEntity) = DownloadController.pause(getApplication(), item.id)
    fun resume(item: DownloadEntity) = DownloadController.resume(getApplication(), item.id)
    fun cancel(item: DownloadEntity) = DownloadController.cancel(getApplication(), item.id)
    fun retry(item: DownloadEntity) { viewModelScope.launch { repo.update(item.copy(status = DownloadStatus.QUEUED, errorMessage = null, retryCount = 0)); DownloadController.start(getApplication(), item.id) } }
    fun delete(item: DownloadEntity) { viewModelScope.launch { repo.delete(item.id); item.localUri?.let { getApplication<Application>().contentResolver.delete(Uri.parse(it), null, null) } } }

    fun clipboardText(): String? = getApplication<Application>().getSystemService(ClipboardManager::class.java)?.primaryClip?.getItemAt(0)?.coerceToText(getApplication())?.toString()
    fun setSetting(key: String, value: Any) { settingsStore.set(key, value); _settings.value = settingsStore.load() }
    fun setFolder(uri: String) = setSetting("folderUri", uri)
}
