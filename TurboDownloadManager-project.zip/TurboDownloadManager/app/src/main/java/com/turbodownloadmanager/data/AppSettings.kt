package com.turbodownloadmanager.data

import android.content.Context
import android.content.SharedPreferences

data class AppSettings(
    val maxSimultaneous: Int = 2,
    val parallelConnections: Int = 4,
    val autoRetry: Boolean = true,
    val maxRetries: Int = 5,
    val wifiOnly: Boolean = false,
    val allowMobileData: Boolean = true,
    val speedLimitBytes: Long = 0,
    val completionNotification: Boolean = true,
    val errorNotification: Boolean = true,
    val darkMode: Int = 0,
    val autoStart: Boolean = true,
    val clipboardDetection: Boolean = true,
    val confirmDelete: Boolean = true,
    val keepHistory: Boolean = true,
    val defaultFolderUri: String? = null
)

class SettingsStore(context: Context) {
    private val p: SharedPreferences = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun load() = AppSettings(
        p.getInt("maxSimultaneous", 2), p.getInt("parallelConnections", 4), p.getBoolean("autoRetry", true),
        p.getInt("maxRetries", 5), p.getBoolean("wifiOnly", false), p.getBoolean("allowMobileData", true),
        p.getLong("speedLimit", 0), p.getBoolean("completionNotification", true), p.getBoolean("errorNotification", true),
        p.getInt("darkMode", 0), p.getBoolean("autoStart", true), p.getBoolean("clipboardDetection", true),
        p.getBoolean("confirmDelete", true), p.getBoolean("keepHistory", true), p.getString("folderUri", null)
    )
    fun set(key: String, value: Any) { p.edit().apply { when (value) { is Int -> putInt(key, value); is Boolean -> putBoolean(key, value); is Long -> putLong(key, value); is String -> putString(key, value) }; apply() } }
}
