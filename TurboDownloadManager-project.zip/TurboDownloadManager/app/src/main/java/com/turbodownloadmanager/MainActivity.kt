package com.turbodownloadmanager

import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.turbodownloadmanager.data.AppSettings
import com.turbodownloadmanager.db.*
import com.turbodownloadmanager.utils.FormatUtils
import com.turbodownloadmanager.utils.UrlUtils
import com.turbodownloadmanager.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm by viewModels<MainViewModel>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) ActivityCompat.requestPermissions(this, arrayOf("android.permission.POST_NOTIFICATIONS"), 100)
        handleIntent(intent)
        setContent { TurboApp(vm) }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent) }
    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") intent.getStringExtra(Intent.EXTRA_TEXT)?.let(vm::setPrefill)
    }
}

enum class Tab(val title: String, val icon: ImageVector) { HOME("Home", Icons.Default.Home), DOWNLOADS("Downloads", Icons.Default.Download), COMPLETED("Completed", Icons.Default.CheckCircle), SETTINGS("Settings", Icons.Default.Settings) }

@Composable fun TurboApp(vm: MainViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val items by vm.downloads.collectAsStateWithLifecycle()
    var tab by remember { mutableStateOf(Tab.HOME) }
    var selected by remember { mutableStateOf<DownloadEntity?>(null) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { vm.message.collect { scope.launch { snackbar.showSnackbar(it) } } }
    val dark = when (settings.darkMode) { 1 -> false; 2 -> true; else -> androidx.compose.foundation.isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = { NavigationBar { Tab.entries.forEach { t -> NavigationBarItem(selected = tab == t, onClick = { tab = t }, icon = { Icon(t.icon, null) }, label = { Text(t.title) }) } } }
        ) { padding ->
            AnimatedContent(tab, modifier = Modifier.padding(padding), label = "screen") { current ->
                when (current) {
                    Tab.HOME -> HomeScreen(items, vm) { selected = it }
                    Tab.DOWNLOADS -> ListScreen("All Downloads", items, vm) { selected = it }
                    Tab.COMPLETED -> ListScreen("Completed", items.filter { it.status == DownloadStatus.COMPLETED }, vm) { selected = it }
                    Tab.SETTINGS -> SettingsScreen(settings, vm)
                }
            }
        }
        selected?.let { DownloadDetail(it, vm) { selected = null } }
    }
}

@Composable private fun HomeScreen(items: List<DownloadEntity>, vm: MainViewModel, onOpen: (DownloadEntity) -> Unit) {
    val prefill by vm.prefill.collectAsStateWithLifecycle()
    var url by remember { mutableStateOf(TextFieldValue("")) }
    LaunchedEffect(prefill) { if (prefill.isNotBlank()) url = TextFieldValue(prefill) }
    val clipboard = LocalClipboardManager.current
    val active = items.filter { it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.PAUSED || it.status == DownloadStatus.FAILED }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("Turbo Download Manager", style = MaterialTheme.typography.headlineMedium) }
        item {
            Card(shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Paste download link", style = MaterialTheme.typography.titleLarge)
                    OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("HTTP / HTTPS URL") }, trailingIcon = { IconButton({ url = TextFieldValue("") }) { Icon(Icons.Default.Clear, "Clear") } })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { clipboard.getText()?.let { url = TextFieldValue(it.text) } }) { Icon(Icons.Default.ContentPaste, null); Spacer(Modifier.width(6.dp)); Text("Paste") }
                        Button(onClick = { vm.addUrl(url.text); url = TextFieldValue("") }, modifier = Modifier.weight(1f), enabled = UrlUtils.normalize(url.text) != null) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(6.dp)); Text("Download") }
                    }
                }
            }
        }
        item { Text("Active Downloads", style = MaterialTheme.typography.titleLarge) }
        if (active.isEmpty()) item { EmptyState("No active downloads", "Add a link above to start a download.", Icons.Default.Download) }
        items(active, key = { it.id }) { DownloadCard(it, vm, onOpen) }
    }
}

@Composable private fun ListScreen(title: String, items: List<DownloadEntity>, vm: MainViewModel, onOpen: (DownloadEntity) -> Unit) {
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(0) }
    val shown = items.filter { it.fileName.contains(query, true) || it.url.contains(query, true) }.let { list -> when(sort) { 1 -> list.sortedBy { it.createdAt }; 2 -> list.sortedByDescending { it.totalBytes }; 3 -> list.sortedBy { it.totalBytes }; 4 -> list.sortedBy { it.fileName.lowercase() }; else -> list } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, label = { Text("Search downloads") })
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { var expanded by remember { mutableStateOf(false) }; Box { TextButton({ expanded = true }) { Text("Sort") }; DropdownMenu(expanded, { expanded = false }) { listOf("Newest", "Oldest", "Largest", "Smallest", "Name").forEachIndexed { i, s -> DropdownMenuItem({ Text(s) }, { sort = i; expanded = false }) } } } }
        if (shown.isEmpty()) EmptyState("No downloads", "Your download history will appear here.", Icons.Default.History)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(shown, key = { it.id }) { DownloadCard(it, vm, onOpen) } }
    }
}

@Composable private fun DownloadCard(item: DownloadEntity, vm: MainViewModel, onOpen: (DownloadEntity) -> Unit) {
    val percent = if (item.totalBytes > 0) (item.downloadedBytes * 100 / item.totalBytes).toInt() else 0
    Card(Modifier.fillMaxWidth().clickable { onOpen(item) }, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(fileIcon(item.mimeType, item.fileName), null); Spacer(Modifier.width(10.dp)); Text(item.fileName, Modifier.weight(1f), maxLines = 1); Text(percent.toString() + "%") }
            LinearProgressIndicator(progress = { if (item.totalBytes > 0) item.downloadedBytes.toFloat() / item.totalBytes else 0f }, modifier = Modifier.fillMaxWidth())
            Row { Text("${FormatUtils.bytes(item.downloadedBytes)} / ${FormatUtils.bytes(item.totalBytes)}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f)); Text(FormatUtils.speed(item.speed), style = MaterialTheme.typography.bodySmall) }
            Text("Remaining: ${FormatUtils.eta(item.downloadedBytes, item.totalBytes, item.speed)}", style = MaterialTheme.typography.bodySmall)
            Row(verticalAlignment = Alignment.CenterVertically) {
                AssistChip(onClick = {}, label = { Text(item.status.name.lowercase().replaceFirstChar { it.uppercase() }) })
                Spacer(Modifier.weight(1f))
                if (item.status == DownloadStatus.DOWNLOADING) IconButton({ vm.pause(item) }) { Icon(Icons.Default.Pause, "Pause") }
                if (item.status == DownloadStatus.PAUSED || item.status == DownloadStatus.FAILED || item.status == DownloadStatus.QUEUED) IconButton({ vm.resume(item) }) { Icon(Icons.Default.PlayArrow, "Resume") }
                if (item.status != DownloadStatus.COMPLETED && item.status != DownloadStatus.CANCELLED) IconButton({ vm.cancel(item) }) { Icon(Icons.Default.Close, "Cancel") }
            }
        }
    }
}

@Composable private fun DownloadDetail(item: DownloadEntity, vm: MainViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(onDismissRequest = onDismiss, title = { Text(item.fileName) }, text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Detail("Status", item.status.name); Detail("URL", item.url); Detail("Size", FormatUtils.bytes(item.totalBytes)); Detail("Downloaded", FormatUtils.bytes(item.downloadedBytes)); Detail("Speed", FormatUtils.speed(item.speed)); Detail("Connections", item.connectionCount.toString()); Detail("Location", item.localPath ?: "Temporary / pending"); Detail("Created", java.text.DateFormat.getDateTimeInstance().format(java.util.Date(item.createdAt))); item.completedAt?.let { Detail("Completed", java.text.DateFormat.getDateTimeInstance().format(java.util.Date(it))) }; item.errorMessage?.let { Detail("Error", it) }
    } }, confirmButton = { Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        if (item.status == DownloadStatus.DOWNLOADING) TextButton({ vm.pause(item); onDismiss() }) { Text("Pause") }
        if (item.status == DownloadStatus.PAUSED || item.status == DownloadStatus.FAILED) TextButton({ vm.resume(item); onDismiss() }) { Text("Resume") }
        if (item.status == DownloadStatus.COMPLETED) { TextButton({ share(context, item) }) { Text("Share") }; TextButton({ openFile(context, item) }) { Text("Open") } }
        TextButton({ vm.delete(item); onDismiss() }) { Text("Delete") }
    } })
}
@Composable private fun Detail(k: String, v: String) { Row { Text("$k: ", style = MaterialTheme.typography.labelMedium); Text(v, maxLines = 3) } }

@Composable private fun SettingsScreen(s: AppSettings, vm: MainViewModel) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> uri?.let { runCatching { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }; vm.setFolder(it.toString()) } }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Settings", style = MaterialTheme.typography.headlineMedium) }
        item { SettingSection("Download") }
        item { ChoiceSetting("Maximum simultaneous downloads", listOf(1,2,3,4).map { it.toString() }, s.maxSimultaneous.toString()) { vm.setSetting("maxSimultaneous", it.toInt()) } }
        item { ChoiceSetting("Parallel connections", listOf(1,2,4,8).map { it.toString() }, s.parallelConnections.toString()) { vm.setSetting("parallelConnections", it.toInt()) } }
        item { SwitchSetting("Auto retry", s.autoRetry) { vm.setSetting("autoRetry", it) } }
        item { ChoiceSetting("Maximum retry count", (1..10).map(Int::toString), s.maxRetries.toString()) { vm.setSetting("maxRetries", it.toInt()) } }
        item { SwitchSetting("Download only on Wi-Fi", s.wifiOnly) { vm.setSetting("wifiOnly", it) } }
        item { SwitchSetting("Allow mobile data", s.allowMobileData) { vm.setSetting("allowMobileData", it) } }
        item { SpeedLimitSetting(s.speedLimitBytes) { vm.setSetting("speedLimit", it) } }
        item { SettingSection("Notifications") }
        item { SwitchSetting("Completion notification", s.completionNotification) { vm.setSetting("completionNotification", it) } }
        item { SwitchSetting("Error notification", s.errorNotification) { vm.setSetting("errorNotification", it) } }
        item { SettingSection("Appearance") }
        item { ChoiceSetting("Theme", listOf("System default","Light","Dark"), listOf(0,1,2)[s.darkMode]) { vm.setSetting("darkMode", listOf("System default","Light","Dark").indexOf(it)) } }
        item { SettingSection("General") }
        item { SwitchSetting("Auto-start downloads", s.autoStart) { vm.setSetting("autoStart", it) } }
        item { SwitchSetting("Clipboard paste helper", s.clipboardDetection) { vm.setSetting("clipboardDetection", it) } }
        item { SwitchSetting("Confirm before deleting", s.confirmDelete) { vm.setSetting("confirmDelete", it) } }
        item { SwitchSetting("Keep download history", s.keepHistory) { vm.setSetting("keepHistory", it) } }
        item { OutlinedButton({ launcher.launch(null) }) { Icon(Icons.Default.Folder, null); Spacer(Modifier.width(8.dp)); Text(if (s.defaultFolderUri == null) "Choose download folder" else "Change download folder") } }
    }
}
@Composable private fun SpeedLimitSetting(value: Long, onValue: (Long) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    var custom by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    val options = listOf("Unlimited","100 KB/s","500 KB/s","1 MB/s","2 MB/s","5 MB/s","Custom")
    Box {
        ListItem(headlineContent = { Text("Speed limit") }, trailingContent = { TextButton({ expanded = true }) { Text(speedLabel(value)) } })
        DropdownMenu(expanded, { expanded = false }) { options.forEach { option -> DropdownMenuItem({ Text(option) }, { expanded = false; if (option == "Custom") custom = true else onValue(speedValue(option)) }) } }
    }
    if (custom) AlertDialog(onDismissRequest = { custom = false }, title = { Text("Custom speed limit") }, text = { OutlinedTextField(text, { text = it }, singleLine = true, label = { Text("KB/s") }) }, confirmButton = { TextButton({ text.toLongOrNull()?.takeIf { it > 0 }?.let { onValue(it * 1024L) }; custom = false }) { Text("Save") } }, dismissButton = { TextButton({ custom = false }) { Text("Cancel") } })
}

@Composable private fun SettingSection(t: String) { Text(t, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 8.dp)) }
@Composable private fun SwitchSetting(t: String, checked: Boolean, on: (Boolean) -> Unit) { ListItem(headlineContent = { Text(t) }, trailingContent = { Switch(checked, on) }) }
@Composable private fun ChoiceSetting(t: String, options: List<String>, selected: String, on: (String) -> Unit) { var expanded by remember { mutableStateOf(false) }; Box { ListItem(headlineContent = { Text(t) }, trailingContent = { TextButton({ expanded = true }) { Text(selected) } }); DropdownMenu(expanded, { expanded = false }) { options.forEach { DropdownMenuItem({ Text(it) }, { on(it); expanded = false }) } } } }
@Composable private fun EmptyState(title: String, subtitle: String, icon: ImageVector) { Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(icon, null, Modifier.size(54.dp)); Text(title, style = MaterialTheme.typography.titleLarge); Text(subtitle, style = MaterialTheme.typography.bodyMedium) } }

private fun fileIcon(mime: String?, name: String): ImageVector = when { mime?.startsWith("video") == true -> Icons.Default.Movie; mime?.startsWith("audio") == true -> Icons.Default.MusicNote; mime?.startsWith("image") == true -> Icons.Default.Image; name.endsWith(".zip", true) || name.endsWith(".rar", true) -> Icons.Default.FolderZip; else -> Icons.Default.InsertDriveFile }
private fun speedLabel(v: Long) = when(v) { 0L -> "Unlimited"; 100*1024L -> "100 KB/s"; 500*1024L -> "500 KB/s"; 1024*1024L -> "1 MB/s"; 2*1024*1024L -> "2 MB/s"; 5*1024*1024L -> "5 MB/s"; else -> "Unlimited" }
private fun speedValue(v: String) = when(v) { "100 KB/s" -> 100*1024L; "500 KB/s" -> 500*1024L; "1 MB/s" -> 1024*1024L; "2 MB/s" -> 2*1024*1024L; "5 MB/s" -> 5*1024*1024L; else -> 0L }
private fun openFile(context: android.content.Context, item: DownloadEntity) { item.localUri?.let { uri ->
    context.startActivity(Intent(Intent.ACTION_VIEW).apply { data = Uri.parse(uri); flags = Intent.FLAG_GRANT_READ_URI_PERMISSION })
} }
private fun share(context: android.content.Context, item: DownloadEntity) { item.localUri?.let { uri ->
    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = item.mimeType ?: "application/octet-stream"; putExtra(Intent.EXTRA_STREAM, Uri.parse(uri)); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Share file"))
} }
