package com.turbodownloadmanager.service

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.turbodownloadmanager.db.AppDatabase
import com.turbodownloadmanager.db.DownloadStatus

class RecoveryWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        runCatching {
            AppDatabase.get(applicationContext).downloadDao().recoverable()
                .filter { it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.DOWNLOADING }
                .forEach { ContextCompat.startForegroundService(applicationContext, Intent(applicationContext, DownloadForegroundService::class.java).setAction(DownloadForegroundService.ACTION_START).putExtra(DownloadController.EXTRA_ID, it.id)) }
        }.onFailure { return Result.retry() }
        return Result.success()
    }
}
