package com.turbodownloadmanager.utils

import kotlin.math.ln
import kotlin.math.pow

object FormatUtils {
    fun bytes(v: Long): String {
        if (v < 0) return "Unknown"
        if (v < 1024) return "$v B"
        val exp = (ln(v.toDouble()) / ln(1024.0)).toInt()
        val unit = "KMGTPE"[exp - 1]
        return "%.1f %sB".format(v / 1024.0.pow(exp.toDouble()), unit)
    }
    fun speed(v: Long) = if (v <= 0) "—" else "${bytes(v)}/s"
    fun eta(downloaded: Long, total: Long, speed: Long): String {
        if (total <= 0 || speed <= 0 || downloaded >= total) return "—"
        val sec = (total - downloaded) / speed
        return when { sec >= 86400 -> "${sec / 86400}d ${sec % 86400 / 3600}h"; sec >= 3600 -> "${sec / 3600}h ${sec % 3600 / 60}m"; sec >= 60 -> "${sec / 60}m ${sec % 60}s"; else -> "${sec}s" }
    }
}
